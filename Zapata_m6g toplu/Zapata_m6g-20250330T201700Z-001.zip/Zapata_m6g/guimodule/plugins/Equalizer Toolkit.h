/// do not modify this file! ///
/*used uplugins start
used uplugins end*/

#ifdef __cplusplus
#include <ValueTypes/value.h>
using namespace FlexitekMath::ValueTypes;
extern "C" {
#else
#define fxValue void
#endif

fxValue* __declspec(dllexport) equalizerfirform(fxValue* parent, fxValue* name);
fxValue* __declspec(dllexport) equalizerfirresult(fxValue* form, fxValue* data);
fxValue* __declspec(dllexport) equalizerfirformName();
fxValue* __declspec(dllexport) equalizerfirformDescription();
fxValue* __declspec(dllexport) equalizerfirresultName();
fxValue* __declspec(dllexport) equalizerfirresultDescription();
fxValue* __declspec(dllexport) equalizer10bandsform(fxValue* parent, fxValue* name);
fxValue* __declspec(dllexport) equalizer10bandsresult(fxValue* form, fxValue* data);
fxValue* __declspec(dllexport) equalizer10bandsformName();
fxValue* __declspec(dllexport) equalizer10bandsformDescription();
fxValue* __declspec(dllexport) equalizer10bandsresultName();
fxValue* __declspec(dllexport) equalizer10bandsresultDescription();
fxValue* __declspec(dllexport) Equaliz10BandForm(fxValue* name);
fxValue* __declspec(dllexport) EqualizFIRForm(fxValue* name);

#ifdef __cplusplus
}
#endif