/// do not modify this file! ///
/*used uplugins start
used uplugins end*/

#ifdef __cplusplus
#include <ValueTypes/value.h>
using namespace FlexitekMath::ValueTypes;
extern "C" {
#else
#define fxValue void
#endif

fxValue* __declspec(dllexport) icpusb_2019_2026_form(fxValue* parent, fxValue* name);
fxValue* __declspec(dllexport) icpusb_2019_2026_form_configure(fxValue* form);
fxValue* __declspec(dllexport) icpusb_2019_2026_formName();
fxValue* __declspec(dllexport) icpusb_2019_2026_formDescription();
fxValue* __declspec(dllexport) icpusb_2019_2026_form_configureName();
fxValue* __declspec(dllexport) icpusb_2019_2026_form_configureDescription();
fxValue* __declspec(dllexport) icpusb_20xx_form(fxValue* parent, fxValue* name);
fxValue* __declspec(dllexport) icpusb_20xx_form_configure(fxValue* form);
fxValue* __declspec(dllexport) icpusb_20xx_formName();
fxValue* __declspec(dllexport) icpusb_20xx_formDescription();
fxValue* __declspec(dllexport) icpusb_20xx_form_configureName();
fxValue* __declspec(dllexport) icpusb_20xx_form_configureDescription();

#ifdef __cplusplus
}
#endif