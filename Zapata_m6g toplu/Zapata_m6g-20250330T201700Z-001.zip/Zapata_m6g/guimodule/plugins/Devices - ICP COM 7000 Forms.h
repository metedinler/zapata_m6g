/// do not modify this file! ///
/*used uplugins start
used uplugins end*/

#ifdef __cplusplus
#include <ValueTypes/value.h>
using namespace FlexitekMath::ValueTypes;
extern "C" {
#else
#define fxValue void
#endif

fxValue* __declspec(dllexport) icpcom_multifunction7000_form(fxValue* parent, fxValue* name);
fxValue* __declspec(dllexport) icpcom_multifunction7000_form_configure(fxValue* form);
fxValue* __declspec(dllexport) icpcom_multifunction7000_formName();
fxValue* __declspec(dllexport) icpcom_multifunction7000_formDescription();
fxValue* __declspec(dllexport) icpcom_multifunction7000_form_configureName();
fxValue* __declspec(dllexport) icpcom_multifunction7000_form_configureDescription();
fxValue* __declspec(dllexport) icpcom_analogoutput7000_form(fxValue* parent, fxValue* name);
fxValue* __declspec(dllexport) icpcom_analogoutput7000_form_configure(fxValue* form);
fxValue* __declspec(dllexport) icpcom_analogoutput7000_formName();
fxValue* __declspec(dllexport) icpcom_analogoutput7000_formDescription();
fxValue* __declspec(dllexport) icpcom_analogoutput7000_form_configureName();
fxValue* __declspec(dllexport) icpcom_analogoutput7000_form_configureDescription();
fxValue* __declspec(dllexport) icpcom_digitalinout7000_form(fxValue* parent, fxValue* name);
fxValue* __declspec(dllexport) icpcom_digitalinout7000_form_configure(fxValue* form);
fxValue* __declspec(dllexport) icpcom_digitalinout7000_formName();
fxValue* __declspec(dllexport) icpcom_digitalinout7000_formDescription();
fxValue* __declspec(dllexport) icpcom_digitalinout7000_form_configureName();
fxValue* __declspec(dllexport) icpcom_digitalinout7000_form_configureDescription();
fxValue* __declspec(dllexport) icpcom_pwmcounter7000_form(fxValue* parent, fxValue* name);
fxValue* __declspec(dllexport) icpcom_pwmcounter7000_form_configure(fxValue* form);
fxValue* __declspec(dllexport) icpcom_pwmcounter7000_formName();
fxValue* __declspec(dllexport) icpcom_pwmcounter7000_formDescription();
fxValue* __declspec(dllexport) icpcom_pwmcounter7000_form_configureName();
fxValue* __declspec(dllexport) icpcom_pwmcounter7000_form_configureDescription();
fxValue* __declspec(dllexport) icpcom_analoginput7017_7019_form(fxValue* parent, fxValue* name);
fxValue* __declspec(dllexport) icpcom_analoginput7017_7019_form_configure(fxValue* form);
fxValue* __declspec(dllexport) icpcom_analoginput7017_7019_formName();
fxValue* __declspec(dllexport) icpcom_analoginput7017_7019_formDescription();
fxValue* __declspec(dllexport) icpcom_analoginput7017_7019_form_configureName();
fxValue* __declspec(dllexport) icpcom_analoginput7017_7019_form_configureDescription();
fxValue* __declspec(dllexport) icpcom_analoginput7011_7016_form(fxValue* parent, fxValue* name);
fxValue* __declspec(dllexport) icpcom_analoginput7011_7016_form_configure(fxValue* form);
fxValue* __declspec(dllexport) icpcom_analoginput7011_7016_formName();
fxValue* __declspec(dllexport) icpcom_analoginput7011_7016_formDescription();
fxValue* __declspec(dllexport) icpcom_analoginput7011_7016_form_configureName();
fxValue* __declspec(dllexport) icpcom_analoginput7011_7016_form_configureDescription();

#ifdef __cplusplus
}
#endif