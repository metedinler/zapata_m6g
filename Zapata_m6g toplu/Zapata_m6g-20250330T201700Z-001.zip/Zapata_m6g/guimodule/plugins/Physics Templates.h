/// do not modify this file! ///
/*used uplugins start
used uplugins end*/

#ifdef __cplusplus
#include <ValueTypes/value.h>
using namespace FlexitekMath::ValueTypes;
extern "C" {
#else
#define fxValue void
#endif

fxValue* __declspec(dllexport) PhysicsTemplate();
fxValue* __declspec(dllexport) PhysicsToolboxWidget_PhysicsToolboxWidget(fxValue* parent);

#ifdef __cplusplus
}
#endif