/// do not modify this file! ///
/*used uplugins start
used uplugins end*/

#ifdef __cplusplus
#include <ValueTypes/value.h>
using namespace FlexitekMath::ValueTypes;
extern "C" {
#else
#define fxValue void
#endif

fxValue* __declspec(dllexport) ljdac_config_form(fxValue* parent, fxValue* name);
fxValue* __declspec(dllexport) ljdac_config_form_configure(fxValue* form);
fxValue* __declspec(dllexport) ljdac_config_formName();
fxValue* __declspec(dllexport) ljdac_config_formDescription();
fxValue* __declspec(dllexport) ljdac_config_form_configureName();
fxValue* __declspec(dllexport) ljdac_config_form_configureDescription();
fxValue* __declspec(dllexport) ljpid_form(fxValue* parent, fxValue* name);
fxValue* __declspec(dllexport) ljpid_formName();
fxValue* __declspec(dllexport) ljpid_formDescription();
fxValue* __declspec(dllexport) ljainT4_config_form(fxValue* parent, fxValue* name);
fxValue* __declspec(dllexport) ljainT4_config_form_configure(fxValue* form);
fxValue* __declspec(dllexport) ljainT4_config_formName();
fxValue* __declspec(dllexport) ljainT4_config_formDescription();
fxValue* __declspec(dllexport) ljainT4_config_form_configureName();
fxValue* __declspec(dllexport) ljainT4_config_form_configureDescription();
fxValue* __declspec(dllexport) ljaintT4_config_form(fxValue* parent, fxValue* name);
fxValue* __declspec(dllexport) ljaintT4_config_form_configure(fxValue* form);
fxValue* __declspec(dllexport) ljaintT4_config_formName();
fxValue* __declspec(dllexport) ljaintT4_config_formDescription();
fxValue* __declspec(dllexport) ljaintT4_config_form_configureName();
fxValue* __declspec(dllexport) ljaintT4_config_form_configureDescription();
fxValue* __declspec(dllexport) ljdioT4_config_form(fxValue* parent, fxValue* name);
fxValue* __declspec(dllexport) ljdioT4_config_form_configure(fxValue* form);
fxValue* __declspec(dllexport) ljdioT4_config_formName();
fxValue* __declspec(dllexport) ljdioT4_config_formDescription();
fxValue* __declspec(dllexport) ljdioT4_config_form_configureName();
fxValue* __declspec(dllexport) ljdioT4_config_form_configureDescription();
fxValue* __declspec(dllexport) ljainT7_config_form(fxValue* parent, fxValue* name);
fxValue* __declspec(dllexport) ljainT7_config_form_configure(fxValue* form);
fxValue* __declspec(dllexport) ljainT7_config_formName();
fxValue* __declspec(dllexport) ljainT7_config_formDescription();
fxValue* __declspec(dllexport) ljainT7_config_form_configureName();
fxValue* __declspec(dllexport) ljainT7_config_form_configureDescription();
fxValue* __declspec(dllexport) ljaintT7_config_form(fxValue* parent, fxValue* name);
fxValue* __declspec(dllexport) ljaintT7_config_form_configure(fxValue* form);
fxValue* __declspec(dllexport) ljaintT7_config_formName();
fxValue* __declspec(dllexport) ljaintT7_config_formDescription();
fxValue* __declspec(dllexport) ljaintT7_config_form_configureName();
fxValue* __declspec(dllexport) ljaintT7_config_form_configureDescription();
fxValue* __declspec(dllexport) ljdioT7_config_form(fxValue* parent, fxValue* name);
fxValue* __declspec(dllexport) ljdioT7_config_form_configure(fxValue* form);
fxValue* __declspec(dllexport) ljdioT7_config_formName();
fxValue* __declspec(dllexport) ljdioT7_config_formDescription();
fxValue* __declspec(dllexport) ljdioT7_config_form_configureName();
fxValue* __declspec(dllexport) ljdioT7_config_form_configureDescription();
fxValue* __declspec(dllexport) LJAI_T4Form(fxValue* name);
fxValue* __declspec(dllexport) LJAI_T4TempForm(fxValue* name);
fxValue* __declspec(dllexport) LJAI_T7Form(fxValue* name);
fxValue* __declspec(dllexport) LJAI_T7TempForm(fxValue* name);
fxValue* __declspec(dllexport) LJDACForm(fxValue* name);
fxValue* __declspec(dllexport) LJDIO_T4Form(fxValue* name);
fxValue* __declspec(dllexport) LJDIO_T7Form(fxValue* name);
fxValue* __declspec(dllexport) LJPIDForm(fxValue* name);

#ifdef __cplusplus
}
#endif