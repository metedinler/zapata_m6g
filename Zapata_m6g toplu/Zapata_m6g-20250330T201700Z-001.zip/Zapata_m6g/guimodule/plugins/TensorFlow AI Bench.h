/// do not modify this file! ///
/*used uplugins start
used uplugins end*/

#ifdef __cplusplus
#include <ValueTypes/value.h>
using namespace FlexitekMath::ValueTypes;
extern "C" {
#else
#define fxValue void
#endif

fxValue* __declspec(dllexport) TensorFlow_AI_BenchToolbox0();
fxValue* __declspec(dllexport) TF1Layer_TF1Layer2(fxValue* mthis, fxValue* parent);
fxValue* __declspec(dllexport) TF3Layer_TF3Layer2(fxValue* mthis, fxValue* parent);
fxValue* __declspec(dllexport) TF5Layer_TF5Layer2(fxValue* mthis, fxValue* parent);
fxValue* __declspec(dllexport) TFMain_TFMain2(fxValue* mthis, fxValue* parent);

#ifdef __cplusplus
}
#endif