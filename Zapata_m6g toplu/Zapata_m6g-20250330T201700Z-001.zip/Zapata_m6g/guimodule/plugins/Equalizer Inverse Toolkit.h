/// do not modify this file! ///
/*used uplugins start
used uplugins end*/

#ifdef __cplusplus
#include <ValueTypes/value.h>
using namespace FlexitekMath::ValueTypes;
extern "C" {
#else
#define fxValue void
#endif

fxValue* __declspec(dllexport) equalizerinverseform(fxValue* parent, fxValue* name);
fxValue* __declspec(dllexport) equalizerinverseresult(fxValue* form, fxValue* data);
fxValue* __declspec(dllexport) equalizerinverseformName();
fxValue* __declspec(dllexport) equalizerinverseformDescription();
fxValue* __declspec(dllexport) equalizerinverseresultName();
fxValue* __declspec(dllexport) equalizerinverseresultDescription();
fxValue* __declspec(dllexport) EqualizerInvForm(fxValue* name);

#ifdef __cplusplus
}
#endif