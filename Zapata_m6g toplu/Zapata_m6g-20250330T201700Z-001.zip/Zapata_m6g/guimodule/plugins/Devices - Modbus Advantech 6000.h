/// do not modify this file! ///
/*used uplugins start
used uplugins end*/

#ifdef __cplusplus
#include <ValueTypes/value.h>
using namespace FlexitekMath::ValueTypes;
extern "C" {
#else
#define fxValue void
#endif

fxValue* __declspec(dllexport) advantechmodbus_6000_form(fxValue* parent, fxValue* name);
fxValue* __declspec(dllexport) advantechmodbus_6000_formName();
fxValue* __declspec(dllexport) advantechmodbus_6000_formDescription();
fxValue* __declspec(dllexport) ADVANTECHMODBUS_6000_Form(fxValue* name);

#ifdef __cplusplus
}
#endif